Na sam początek utwórz punkt przywracania systemu !!!
- Jeśli coś zrobił/a byś nie tak zawsze będzie można wrócić do podstawowej wersji systemu -