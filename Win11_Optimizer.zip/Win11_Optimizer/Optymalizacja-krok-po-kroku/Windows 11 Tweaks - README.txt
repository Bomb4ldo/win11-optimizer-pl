Windows 11 Tweaks

- Wszystkie pliki są bezpieczne i odwracalne
- REG: kliknij 2x (najlepiej otworzyć jako administrator)
- BAT: uruchom jako administrator

Zawartość:
- Fast Startup ON/OFF
- Game DVR ON/OFF
- Sterowniki auto ON/OFF
- Hibernacja ON/OFF
- Tryb najwyższej wydajności

Optymalizacje Sieci - mniejszy ping poprzez zmiane ustawień to mit!
