@echo off
echo Removing optional Windows apps...

:: 3D Viewer / Print 3D
powershell "Get-AppxPackage *Microsoft.Print3D* | Remove-AppxPackage"
powershell "Get-AppxPackage *Microsoft.Microsoft3DViewer* | Remove-AppxPackage"

:: Maps
powershell "Get-AppxPackage *WindowsMaps* | Remove-AppxPackage"

:: Get Help
powershell "Get-AppxPackage *GetHelp* | Remove-AppxPackage"

:: Cortana
powershell "Get-AppxPackage *Microsoft.549981C3F5F10* | Remove-AppxPackage"

:: Windows Hello Face (bio)
powershell "Get-AppxPackage *BioEnrollment* | Remove-AppxPackage"

echo Done.
pause