@echo off
echo Restoring Windows apps...

powershell "Get-AppxPackage -allusers Microsoft.WindowsStore | Foreach {Add-AppxPackage -DisableDevelopmentMode -Register '$($_.InstallLocation)\AppxManifest.xml'}"

echo Some apps may require reinstall from Store.
pause