@echo off
echo Removing OneDrive...

taskkill /f /im OneDrive.exe

:: uninstall per user
%SystemRoot%\SysWOW64\OneDriveSetup.exe /uninstall
%SystemRoot%\System32\OneDriveSetup.exe /uninstall

echo Done.
pause