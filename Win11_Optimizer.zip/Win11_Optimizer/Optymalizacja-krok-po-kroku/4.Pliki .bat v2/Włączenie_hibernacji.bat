@echo off
powercfg -h on
pause