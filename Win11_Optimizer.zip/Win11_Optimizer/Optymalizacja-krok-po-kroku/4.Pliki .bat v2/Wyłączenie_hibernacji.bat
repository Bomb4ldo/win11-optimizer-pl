@echo off
powercfg -h off
pause