@echo off
echo Installing OneDrive...

:: reinstall
%SystemRoot%\SysWOW64\OneDriveSetup.exe
%SystemRoot%\System32\OneDriveSetup.exe

echo Done.
pause