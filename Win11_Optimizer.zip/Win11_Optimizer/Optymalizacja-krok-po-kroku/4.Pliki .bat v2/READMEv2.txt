Windows 11 Tweaks

- Wszystkie pliki są bezpieczne i odwracalne
- BAT: uruchom jako administrator