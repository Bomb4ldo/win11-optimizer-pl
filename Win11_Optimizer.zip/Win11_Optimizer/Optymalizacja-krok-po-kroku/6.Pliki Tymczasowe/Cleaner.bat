@echo off
echo Cleaning system junk files...

:: Temp (system)
del /s /f /q %windir%\Temp\* >nul 2>&1
for /d %%x in (%windir%\Temp\*) do rd /s /q "%%x" >nul 2>&1

:: User Temp (%temp%)
del /s /f /q %temp%\* >nul 2>&1
for /d %%x in (%temp%\*) do rd /s /q "%%x" >nul 2>&1

:: Prefetch (cache aplikacji)
del /s /f /q C:\Windows\Prefetch\* >nul 2>&1

echo Done cleaning.
pause